/*Indice Pruebas Laboratorio*/
SELECT * FROM PruebaDeLaboratorio WHERE id_prueba = 10001;
/*Indice Jornadas de Vacunacion - Tipo de Vacuna*/
SELECT * FROM JornadasDeVacunacion WHERE id_jornada = 7001;
/*Vistas*/
SELECT * FROM Vista_Pacientes_Pruebas_Diagnosticos;