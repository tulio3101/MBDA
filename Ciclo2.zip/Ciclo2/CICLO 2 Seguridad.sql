CREATE ROLE Gerente_Laboratorio;
GRANT EXECUTE ON PA_GERENTE_LABORATORIO TO Gerente_Laboratorio;
----------------------------------------------------------------
CREATE ROLE Jefe_Laboratorio;
GRANT EXECUTE ON PA_JEFE_LABORATORIO TO Jefe_Laboratorio
----------------------------------------------------------------
CREATE ROLE Junta;
GRANT EXECUTE ON PA_JUNTA_ADMINISTRATIVA TO Junta;
----------------------------------------------------------------
CREATE ROLE Secretario;
GRANT EXECUTE ON PA_SECRETARIO TO Secretario;
