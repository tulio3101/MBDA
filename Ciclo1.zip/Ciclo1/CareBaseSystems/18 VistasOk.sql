SELECT * 
FROM Entidades_Diagnostico;

SELECT * FROM Pacientes WHERE id = 1;

SELECT * FROM HistoriasClinicas WHERE historia_id = 1;