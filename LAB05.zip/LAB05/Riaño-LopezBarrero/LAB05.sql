/*Tablas*/
CREATE TABLE Usuarios(
             id VARCHAR(5) NOT NULL, 
             fechaRegistro DATE NOT NULL, 
             correoElectronico VARCHAR(50) NOT NULL
            );
            
-- LAB 05
CREATE TABLE numerosContactos(
        numeroContacto VARCHAR(12) NOT NULL,
        idusuario VARCHAR(5) NOT NULL
    );
            
CREATE TABLE PersonaNaturales(
             tipoDocumento VARCHAR(25), 
             numeroDocumento VARCHAR(25),
             nombres VARCHAR(100) NOT NULL, 
             nacionalidad varchar(10) NOT NULL, 
             idusuario VARCHAR(5)NOT NULL
             );
             
CREATE TABLE Empresas(
             nit VARCHAR(10), 
             razonSocial VARCHAR(100) NOT NULL, 
             idusuario VARCHAR(5)NOT NULL
             );
             

CREATE TABLE Demandas(
             idusuario VARCHAR(5) NOT NULL, 
             numero VARCHAR(5) NOT NULL, 
             fecha DATE NOT NULL, 
             tipoVivienda VARCHAR(25) , 
             maxCompra NUMBER NOT NULL);
             
CREATE TABLE Avisos(
             numeroDemanda VARCHAR(5)NOT NULL, 
             id VARCHAR(5) NOT NULL, 
             fechaCreacion DATE NOT NULL, 
             mensaje VARCHAR(30) NOT NULL, 
             estado VARCHAR(10) NOT NULL, 
             usuario VARCHAR(25) NOT NULL);
             
CREATE TABLE OrigenFondos(
             numeroDemanda VARCHAR(5)NOT NULL, 
             valor NUMBER NOT NULL, 
             credito NUMBER(1) NOT NULL, 
             estaAprobado NUMBER(1)
             );
             
CREATE TABLE InteresEn(
             codigoUbicacion VARCHAR(11) NOT NULL, 
             numeroDemanda VARCHAR(5)NOT NULL ,
             nivel VARCHAR(25) NOT NULL );

CREATE TABLE Ofertas(
            codigoUbicacion VARCHAR(11) NOT NULL, 
            numero NUMBER NOT NULL,
            fecha DATE NOT NULL,
            direccion VARCHAR(50) NOT NULL,
            tipoVivienda VARCHAR(25) NOT NULL,
            costo NUMBER NOT NULL,
            anexos VARCHAR(25) NULL,
            estado VARCHAR(25) NOT NULL,
            idusuario VARCHAR(5)NOT NULL);
            
CREATE TABLE Fotografias(
             nombre VARCHAR(15) NOT NULL, 
             ruta VARCHAR(100) NOT NULL, 
             descripcion VARCHAR(100) NOT NULL);
             
CREATE TABLE PermiteFotografias(
             numeroOferta NUMBER NOT NULL,
             nombreFotografia VARCHAR(15) NOT NULL);
             
CREATE TABLE OpcionesCreditos(
             plazo NUMBER NOT NULL,
             valorMensual NUMBER NOT NULL,
             numeroOferta NUMBER NOT NULL);

CREATE TABLE Ubicaciones(
             codigo VARCHAR(11) NOT NULL,
             latitud NUMBER(3) NOT NULL ,
             longitud NUMBER(3) NOT NULL,
             ciudad VARCHAR(10) NOT NULL,
             zona VARCHAR(25) NOT NULL ,
             barrio VARCHAR(10) NOT NULL);
             
CREATE TABLE Alertas(
        idAlertas VARCHAR(5) NOT NULL,
        fechaCreacion DATE NOT NULL,
        mensaje VARCHAR(30) NOT NULL,
        estado VARCHAR(10) NOT NULL,
        usuario VARCHAR(25) NOT NULL,
        alertaEstado VARCHAR(15) NOT NULL,
        hora DATE NOT NULL,
        datos VARCHAR(25) NOT NULL
    );

CREATE TABLE Notificaciones(
        idNotificaciones VARCHAR(5) NOT NULL,
        fechaCreacion DATE NOT NULL,
        mensaje VARCHAR(30) NOT NULL,
        estado VARCHAR(30) NOT NULL,
        usuario VARCHAR(25) NOT NULL
    );

/*PK*/
ALTER TABLE Usuarios ADD CONSTRAINT PK_Usuarios PRIMARY KEY (id);

ALTER TABLE numerosContactos ADD CONSTRAINT PK_numerosContactos PRIMARY KEY(numeroContacto);

ALTER TABLE PersonaNaturales ADD CONSTRAINT PK_PersonaNaturales PRIMARY KEY (nombres);

ALTER TABLE Empresas ADD CONSTRAINT PK_Empresas PRIMARY KEY (razonSocial);

ALTER TABLE Demandas ADD CONSTRAINT PK_Demandas PRIMARY KEY (numero);

ALTER TABLE Avisos ADD CONSTRAINT PK_Avisos PRIMARY KEY (id);

ALTER TABLE OrigenFondos ADD CONSTRAINT PK_OrigenFondos PRIMARY KEY (numeroDemanda);

ALTER TABLE InteresEn ADD CONSTRAINT PK_InteresEn PRIMARY KEY (numeroDemanda, codigoUbicacion);

ALTER TABLE Ofertas ADD CONSTRAINT PK_Ofertas PRIMARY KEY (numero);

ALTER TABLE Fotografias ADD CONSTRAINT PK_Fotografias PRIMARY KEY (nombre);

ALTER TABLE PermiteFotografias ADD CONSTRAINT PK_PermiteFotografias PRIMARY KEY (numeroOferta, nombreFotografia);

ALTER TABLE OpcionesCreditos ADD CONSTRAINT PK_OpcionesCreditos PRIMARY KEY (plazo);

ALTER TABLE Ubicaciones ADD CONSTRAINT PK_Ubicaciones PRIMARY KEY (codigo);

ALTER TABLE Alertas ADD CONSTRAINT PK_ALERTAS PRIMARY KEY(alertaEstado);

ALTER TABLE Notificaciones ADD CONSTRAINT PK_NOTIFICACIONES PRIMARY KEY(mensaje);

/*FK*/
ALTER TABLE PersonaNaturales ADD CONSTRAINT FK_PersonaNaturales_Usuarios FOREIGN KEY (idusuario) REFERENCES Usuarios(id);

ALTER TABLE Empresas ADD CONSTRAINT FK_Empresas_Usuarios FOREIGN KEY (idusuario)REFERENCES Usuarios(id);

ALTER TABLE Demandas ADD CONSTRAINT FK_Demandas_Usuarios FOREIGN KEY (idusuario)REFERENCES Usuarios(id);

ALTER TABLE Avisos ADD CONSTRAINT FK_Avisos_Demandas FOREIGN KEY (numeroDemanda)REFERENCES Demandas(numero);

ALTER TABLE OrigenFondos ADD CONSTRAINT FK_OrigenFondos_Demandas FOREIGN KEY (numeroDemanda)REFERENCES Demandas(numero);

ALTER TABLE InteresEn ADD CONSTRAINT FK_InteresEn_Ubicaciones FOREIGN KEY (codigoUbicacion)REFERENCES Ubicaciones(codigo);

ALTER TABLE InteresEn ADD CONSTRAINT FK_InteresEn_Demandas FOREIGN KEY (numeroDemanda)REFERENCES Demandas(numero);

ALTER TABLE Ofertas ADD CONSTRAINT FK_Ofertas_Ubicaciones FOREIGN KEY (codigoUbicacion)REFERENCES Ubicaciones(codigo);

ALTER TABLE Ofertas ADD CONSTRAINT FK_Ofertas_Usuarios FOREIGN KEY (idusuario)REFERENCES Usuarios(id);

ALTER TABLE PermiteFotografias ADD CONSTRAINT FK_PermiteFotografias_Ofertas FOREIGN KEY (numeroOferta)REFERENCES Ofertas(numero);

ALTER TABLE PermiteFotografias ADD CONSTRAINT FK_PermiteFotografias_Fotografias FOREIGN KEY (nombreFotografia)REFERENCES Fotografias(nombre);

ALTER TABLE OpcionesCreditos ADD CONSTRAINT FK_OpcionesCreditos_Ofertas FOREIGN KEY (numeroOferta)REFERENCES Ofertas(numero);

ALTER TABLE Alertas ADD CONSTRAINT FK_Alertas_Avisos FOREIGN KEY (idAlertas)REFERENCES Avisos(id);

ALTER TABLE Notificaciones ADD CONSTRAINT FK_Notificaciones_Avisos FOREIGN KEY (idNotificaciones)REFERENCES Avisos(id);

/*UK*/

ALTER TABLE PersonaNaturales ADD CONSTRAINT Uk_PersonaNaturales UNIQUE (tipoDocumento, numeroDocumento);

ALTER TABLE Empresas ADD CONSTRAINT Uk_Empresas_Nit UNIQUE (nit);

/*Atributos O Condiciones de Tuplas*/

ALTER TABLE Usuarios ADD CONSTRAINT CK_Usuarios_Correo CHECK (correoElectronico LIKE '%@%');

ALTER TABLE Demandas ADD CONSTRAINT CK_Demandas_MaxCompra CHECK (maxCompra > 0);

ALTER TABLE OrigenFondos ADD CONSTRAINT CK_OrigenFondos CHECK(credito IN (0,1));

ALTER TABLE OrigenFondos ADD CONSTRAINT CK_OrigenFondos_EstaAprobado CHECK(estaAprobado IN (0,1));

/*PoblarOK*/
INSERT INTO Usuarios VALUES ('10001',TO_DATE('28-SEP-2024 20:55:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario01@gmail.com'); 
INSERT INTO Usuarios VALUES ('10002',TO_DATE('04-FEB-2024 18:05:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario02@gmail.com');
INSERT INTO Usuarios VALUES ('10003',TO_DATE('13-OCT-2024 10:13:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario03@gmail.com');
 
INSERT INTO numerosContactos VALUES ('3167690706','10001');
INSERT INTO numerosContactos VALUES ('3217911026','10002');
INSERT INTO numerosContactos VALUES ('305102423786','10003');


INSERT INTO PersonaNaturales VALUES ('Cedula', '1234567', 'Juan', 'Colombiana','10001');
INSERT INTO PersonaNaturales VALUES ('Cedula', '7654321', 'Maria', 'Mexicana','10002');
INSERT INTO PersonaNaturales VALUES ('Cedula', '9876543', 'Pedro', 'Argentino','10003');
 

INSERT INTO Empresas VALUES ('95687568-3','Empresa Publica de Telecomunicaciones de Colombia S.A.','10001');
INSERT INTO Empresas VALUES ('12374471-2','Comercial Mexicana de Pinturas S.A. de C.V.','10002');
INSERT INTO Empresas VALUES ('28145672-5','Aerolineas Argentinas S.A.','10003');
 

INSERT INTO Demandas VALUES ('10001','98765',TO_DATE('2024/09/22','yyyy/mm/dd'),'Bodega',400000000);
INSERT INTO Demandas VALUES ('10002','45678',TO_DATE('2024/04/12','yyyy/mm/dd'),'Apartamento',1005690);
INSERT INTO Demandas VALUES ('10003','12365',TO_DATE('2024/06/04','yyyy/mm/dd'),'Casa',20000000);
 

INSERT INTO Avisos VALUES ('98765', '00101', TO_DATE('2024/08/11', 'yyyy/mm/dd'), 'Recibi notificacion', 'Pendiente', 'AdministradorNegocio');
INSERT INTO Avisos VALUES ('45678', '00102', TO_DATE('2024/07/14', 'yyyy/mm/dd'), 'Busco asesoria legal', 'Enviada', 'DuenodelaInfo');
INSERT INTO Avisos VALUES ('12365', '00103', TO_DATE('2024/12/02', 'yyyy/mm/dd'), 'Informar situacion', 'Fallida', 'DuenodelaInfo');
 

INSERT INTO OrigenFondos VALUES ('98765', 300000000, 1, 1);  -- Credito=true, Aprobado=true
INSERT INTO OrigenFondos VALUES ('45678', 800000, 1, NULL);  -- Credito=true, Aprobado=null
INSERT INTO OrigenFondos VALUES ('12365', 15000000, 0, 0);   -- Credito=false, Aprobado=false
 
INSERT INTO Ubicaciones VALUES ('98765432100', -74, 485, 'Bogota', 'Norte', 'Chapinero');
INSERT INTO Ubicaciones VALUES ('12345678900', -98, 197, 'Mexico', 'Centro', 'Lomas');
INSERT INTO Ubicaciones VALUES ('09876543211', -545, -387, 'Canada', 'Sur', 'Palermo');


INSERT INTO InteresEn VALUES ('98765432100', '98765', 'Alto');
INSERT INTO InteresEn VALUES ('12345678900', '45678', 'Medio');
INSERT INTO InteresEn VALUES ('09876543211', '12365', 'Bajo');
 

INSERT INTO Ofertas VALUES ('98765432100', 67890, TO_DATE('2024/09/25', 'yyyy/mm/dd'), 'Calle 123 #45-67', 'Bodega', 450000000, NULL, 'Pendiente', '10001');
INSERT INTO Ofertas VALUES ('12345678900', 54321, TO_DATE('2024/03/15', 'yyyy/mm/dd'), 'Avenida 789 #12-34', 'Apartamento', 1200000, 'Contrato.pdf', 'Aceptada', '10001');
INSERT INTO Ofertas VALUES ('09876543211', 98765, TO_DATE('2024/07/30', 'yyyy/mm/dd'), 'Calle 567 #89-90', 'Casa', 25000000, 'Fotos.zip', 'Rechazada', '10003');
 

INSERT INTO Fotografias VALUES ('Foto1', '/imagenes/foto1.jpg', 'Vista frontal de la propiedad');
INSERT INTO Fotografias VALUES ('Foto2', '/imagenes/foto2.jpg', 'Vista interior del apartamento');
INSERT INTO Fotografias VALUES ('Foto3', '/imagenes/foto3.jpg', 'Vista panoramica del barrio');
 

INSERT INTO PermiteFotografias VALUES (67890, 'Foto1');
INSERT INTO PermiteFotografias VALUES (54321, 'Foto2');
INSERT INTO PermiteFotografias VALUES (98765, 'Foto3');
 

INSERT INTO OpcionesCreditos VALUES (20, 15000000, 67890);
INSERT INTO OpcionesCreditos VALUES (15, 1000000, 54321);
INSERT INTO OpcionesCreditos VALUES (30, 500000, 98765);
 

INSERT INTO Notificaciones VALUES ('00101', TO_DATE('2024/10/10', 'yyyy/mm/dd'), 'Notificacion recibida', 'Leida', 'usuario01');
INSERT INTO Notificaciones VALUES ('00102', TO_DATE('2024/10/11', 'yyyy/mm/dd'), 'Recordatorio de pago', 'Enviada', 'usuario02');
INSERT INTO Notificaciones VALUES ('00103', TO_DATE('2024/10/12', 'yyyy/mm/dd'), 'Actualizacion de datos', 'Pendiente', 'usuario03');
 

INSERT INTO Alertas VALUES ('00101', TO_DATE('2024/10/10', 'yyyy/mm/dd'), 'Revisar documentos', 'Pendiente', 'usuario01', 'Activa', TO_DATE('2024/10/10 10:00:00', 'yyyy/mm/dd hh24:mi:ss'), 'Documento vencido');
INSERT INTO Alertas VALUES ('00102', TO_DATE('2024/10/11', 'yyyy/mm/dd'), 'Pago pendiente', 'Enviada', 'usuario02', 'Urgente', TO_DATE('2024/10/11 09:00:00', 'yyyy/mm/dd hh24:mi:ss'), 'Pago mensualidad');
INSERT INTO Alertas VALUES ('00103', TO_DATE('2024/10/12', 'yyyy/mm/dd'), 'Actualizacion de contrato', 'Pendiente', 'usuario03', 'Normal', TO_DATE('2024/10/12 15:00:00', 'yyyy/mm/dd hh24:mi:ss'), 'Contrato por vencer');


/*PoblarNoOK*/

INSERT INTO Demandas VALUES ('999999', '12345', TO_DATE('2024/09/01', 'yyyy/mm/dd'), 'Casa', 500000000); /*El id del usuario no existe en usuarios*/
INSERT INTO OrigenFondos VALUES ('12345', 'cien mil', 'Cr?ditoH', 'Aprobado');/*Para la segunda casilla corresponde aun valor tipo entero, no de cadena*/
INSERT INTO Usuarios VALUES ('10004', TO_DATE('2024/10/01', 'yyyy/mm/dd'), NULL, '3125555555');/*Coloca un Null en columna definifa como no null*/


INSERT INTO Usuarios VALUES ('10005', TO_DATE('2024/09/30', 'yyyy/mm/dd'), 'usuario05gmail.com', '3125555555');/*Recibe correos sin @*/
INSERT INTO Demandas VALUES ('10001', '98766', TO_DATE('2024/09/29', 'yyyy/mm/dd'), 'Casa', -50000000);/*el valos maximo de la compra es negativo*/
INSERT INTO PersonaNaturales VALUES ('Cedula', '1234567', 'Carlos', 'Colombiana', '10004'); /*Ingrsan 2 personas distintas con el mismo numero de cedula*/
INSERT INTO PersonaNaturales VALUES ('Cedula', '1234567', 'Luis', 'Colombiana', '10005');
/**/

/*Para el primer y segundo caso, ya implementamos las restriciones pertienentes*/
/*Para el tercer caso, con la implementacion de la UK recupera integridad*/

INSERT INTO PersonaNaturales VALUES ('Cedula','9876543', null, 'Argentino','10003'); /*Se va a rechazar porque el valor en el nombre no puede ser null*/
INSERT INTO Usuarios VALUES ('1000189',TO_DATE('28-SEP-2024 20:55:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario01@gmail.com','3124338358'); /*La insercion sera negada porque el id se desborda*/
INSERT INTO Usuarios VALUES ('10005', TO_DATE('2024/09/30', 'yyyy/mm/dd'), 'usuario05gmail.com', '3125555555');/*Recibe correos sin @*/ /*No recibira valores de correo sin el @*/

/*REGISTRA OFERTA*/

-------/*ADICIONAR*/-------
 
-- El numero, fecha y estado de la oferta es autogenerado
CREATE SEQUENCE id_num1
    INCREMENT BY 1
    START WITH 1
    MINVALUE 1
    MAXVALUE 99999
    CYCLE;
 
-- Disparador para registrar oferta
CREATE OR REPLACE TRIGGER T1
BEFORE INSERT ON Ofertas
FOR EACH ROW
DECLARE
    num_oferta NUMBER;
BEGIN
    SELECT id_num1.NEXTVAL INTO num_oferta FROM dual;
    :NEW.NUMERO := num_oferta;
    :NEW.FECHA := SYSDATE;
    :NEW.ESTADO := 'Disponible';
END;
/*Disparador OK*/
INSERT INTO Ofertas VALUES ('98765432100', NULL, NULL, 'Calle 123 #45-67', 'Bodega', 450000000, NULL, NULL, '10001');
SELECT * FROM Ofertas;
/*Disparador No Ok*/ --Intento de asignar estado manualmente
INSERT INTO Ofertas VALUES ('98765432100', NULL, TO_DATE('2024/09/25', 'yyyy/mm/dd'), 'Calle 123 #45-67', 'Casa', 350000000, NULL, 'Vendida', '10001');
SELECT * FROM Ofertas;
DROP TRIGGER T1;

-- Se asume que todas las viviendas tienen una opcion de credito a 12 meses con cuotas mensuales equivalentes al costo mas 10% dividido en 12.
CREATE OR REPLACE TRIGGER T22
BEFORE INSERT ON OpcionesCreditos
FOR EACH ROW
DECLARE
    COSTO_1 NUMBER;
BEGIN
    SELECT costo INTO COSTO_1
    FROM Ofertas
    WHERE numero = :NEW.numeroOferta; 
    :NEW.valorMensual := COSTO_1 * 0.1 / 12; 
    :NEW.plazo := 12; 
END;
/*Disparador OK*/
INSERT INTO OpcionesCreditos VALUES (NULL, NULL, '67890');
SELECT * FROM OpcionesCreditos;
SELECT * FROM Ofertas;
DELETE FROM OpcionesCreditos WHERE numeroOferta = '67890';
/*Disparador No Ok*/
INSERT INTO OpcionesCreditos VALUES (24,25000000,'67890');
SELECT * FROM OpcionesCreditos;
-- Intento de establecer plazo y valor mensual manualmente
DROP TRIGGER T22;
 
-- Solo se pueden modificar los anexos, las fotografías y la opción de crédito
CREATE OR REPLACE TRIGGER T3
BEFORE UPDATE OF codigoUbicacion, numero, fecha, direccion, tipoVivienda, costo, estado, idusuario ON Ofertas
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20001, 'No se puede modificar el n�mero, fecha, direcci�n, tipoVivienda, costo, estado, idusuarios');
END;

/*Disparador OK*/
INSERT INTO Ofertas VALUES ('12345678900', '54221', TO_DATE('2024/03/15', 'yyyy/mm/dd'), 'Avenida 789 #12-34', 'Apartamento', 1200000, 'Contrato.pdf', 'Aceptada', '10001');
SELECT * FROM Ofertas;
/*Disparador No Ok*/
INSERT INTO Ofertas VALUES ('12345678900', '54321', TO_DATE('2024/04/01', 'yyyy/mm/dd'), 'Calle 789 #56-78', 'Apartamento', 2000000, 'Contrato.pdf', 'Aceptada', '10001');
UPDATE Ofertas SET estado = 'Vendida' WHERE numero = '54321';
DROP TRIGGER T3;

-- Se pueden adicionar o eliminar fotografías a la galeria
CREATE OR REPLACE TRIGGER T4
BEFORE UPDATE ON Fotografias
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20002, 'Solo se puede insertar o eliminar fotografias');
END;

/*Disparador Ok*/
INSERT INTO Fotografias VALUES (1, '/fotos/casa1.jpg','Fachada principal');

/*Disparador No Ok*/

UPDATE Fotografias SET ruta =  '/fotos/casa1.jpg' WHERE nombre = 'Fachada principal';

DROP TRIGGER T4;
 
-- Se puede eliminar la opci�n de credito o modificar las condiciones. Las cuotas por el numero de meses debe ser mayor o igual al costo
CREATE OR REPLACE TRIGGER T5
BEFORE UPDATE OF plazo, valormensual ON OpcionesCreditos
FOR EACH ROW
DECLARE
    COSTO NUMBER;
BEGIN
    SELECT costo INTO COSTO
    FROM Ofertas
    WHERE numero = :NEW.numeroOferta;

    IF (:NEW.plazo * :NEW.valormensual) < COSTO THEN
        RAISE_APPLICATION_ERROR(-20003, 'La multiplicación del plazo por las cuotas debe ser mayor o igual al costo');
    END IF;
END;

/*Disparador Ok*/
INSERT INTO Ofertas VALUES ('98765432100', 'OF001', TO_DATE('2024/10/25', 'yyyy/mm/dd'), 'Calle 123 #45-67', 'Casa', 100000000, 'Documentos', 'Disponible', '10001');
INSERT INTO OpcionesCreditos VALUES (13,9000000, 'OF001');
SELECT * FROM OpcionesCreditos;
SELECT * FROM Ofertas;
/*Disparador No Ok*/
UPDATE OpcionesCreditos SET plazo = 6, valorMensual = 8000000
WHERE numeroOferta = 'OF001';
DROP TRIGGER T5;
 
-- Una oferta puede ser eliminada siempre y cuando sea la última
CREATE OR REPLACE TRIGGER T6
BEFORE DELETE ON Ofertas
FOR EACH ROW
DECLARE
    num NUMBER;
BEGIN
    SELECT COUNT(*) INTO num FROM Ofertas WHERE idusuario = :OLD.idusuario;
    IF num > :OLD.numero THEN
        RAISE_APPLICATION_ERROR(-20004, 'Solo se puede eliminar si es la última oferta.');
    END IF;
END;
/*Disparador Ok*/
INSERT INTO Ofertas VALUES ('98765432100', 'OF002', SYSDATE, 'Calle 124 #45-67', 'Casa', 120000000, 'Documentos', 'Disponible', '10001');
INSERT INTO Ofertas VALUES ('98765432100', 'OF004', SYSDATE, 'Calle 124 #45-67', 'Casa', 120000000, 'Documentos', 'Disponible', '10003');
SELECT * FROM Usuarios;
SELECT * FROM Ofertas;
/*Disparador No Ok*/
DELETE FROM Ofertas WHERE idusuario = '10001' AND numero = 'OF002';
DROP TRIGGER T6;
 

-------/*ADICIONAR*/-------
/*El Numero y La Fecha Se genera Automaticamente*/
-- Secuencia Para Demanda Punto 1 --
CREATE SEQUENCE id_num_demanda
    INCREMENT BY 1
    START WITH 1
    MINVALUE 1
    MAXVALUE 99999
    CYCLE;

CREATE OR REPLACE TRIGGER T7
BEFORE INSERT ON Demandas
FOR EACH ROW
DECLARE
num_oferta NUMBER;
BEGIN
SELECT id_num_demanda.NEXTVAL INTO num_oferta FROM dual;
:NEW.fecha := SYSDATE;
END;

/*Disparador Ok*/
INSERT INTO Demandas VALUES(
    '10001',              
    'D742',             
    NULL,            
    'Apartamento',      
    200000000           
);
SELECT * FROM Usuarios;
SELECT * FROM DEMANDAS;
/*Disparador No Ok*/
INSERT INTO Demandas VALUES ('10001', 'D922', TO_DATE('2024/05/01', 'yyyy/mm/dd'), 'Casa', 150000000);
DROP TRIGGER T7;


/*Si no se indica el tipo de vivienda, se asume que es casa.*/
CREATE TRIGGER T8
BEFORE INSERT ON Demandas
FOR EACH ROW 
BEGIN 
    IF :NEW.tipoVivienda IS NULL THEN
       :NEW.tipoVivienda := 'casa';
    END IF;
END;

/*Disparador oK*/
INSERT INTO Demandas VALUES(
    '10001',             
    'D333',             
    SYSDATE,            
    NULL,              
    150000000           
);
SELECT * FROM DEMANDAS;

/*Disparador No Ok*/
INSERT INTO Demandas VALUES ('10001', 'D555', SYSDATE, 'Oficina', 160000000);

DROP TRIGGER T8;

-- Se asume que solicit� un prestamo por el valor total de la compra.
CREATE OR REPLACE TRIGGER T13
BEFORE INSERT ON OrigenFondos
FOR EACH ROW
DECLARE
    valor_1 NUMBER;
BEGIN
    SELECT maxCompra INTO valor_1
    FROM Demandas
    WHERE numero = :NEW.numeroDemanda;
    :NEW.valor := valor_1;
    :NEW.credito := 1;
    :NEW.estaAprobado := 0;
END;

/*Disparador Ok*/

INSERT INTO Demandas VALUES ('10001', 'D019', SYSDATE, 'Casa', 150000);
INSERT INTO Demandas VALUES ('10002', 'D112', SYSDATE, 'Apartamento', 200000);


SELECT * FROM DEMANDAS;
/*Disparador No Ok*/
INSERT INTO OrigenFondos VALUES ('D999', 50000, 1, 0);

DROP TRIGGER T13;



-------/*MODIFICAR*/-------

-- Puede indicar si el prestamo fue aprobado o no.
CREATE OR REPLACE TRIGGER T9
BEFORE UPDATE ON OrigenFondos
FOR EACH ROW
BEGIN
    IF :OLD.Credito = 1 THEN
    :NEW.estaAprobado := 1;
    ELSE
    :NEW.estaAprobado := 0;
    END IF;
END;

/*Disparador OK*/
INSERT INTO OrigenFondos VALUES('D001', 100000000, 1, 0);


/*Disparador No Ok*/
INSERT INTO Demandas VALUES('10001', 'D004', SYSDATE, 'Casa', 170000000);
INSERT INTO OrigenFondos VALUES('D004', 100000000, 0, 1);

UPDATE OrigenFondos SET estaAprobado = 1 --Establecer estaAprobado = 1 cuando credito = 0
WHERE numeroDemanda = 'D004'; -- El trigger forzar� el 0

SELECT * FROM OrigenFondos;
DROP TRIGGER T9;

/*
Puede adicionar ubicaciones de interés, no eliminarlas ni modificarlas.
*/
CREATE OR REPLACE TRIGGER T10 
BEFORE UPDATE ON InteresEn 
FOR EACH ROW 
BEGIN    
    -- Ahora el mensaje es m�s espec�fico
    RAISE_APPLICATION_ERROR(
        -20045, 
        'No se puede actualizar registros en InteresEn. Los campos codigoUbicacion, numeroDemanda y nivel son inmutables.'
    ); 
END;


-- Trigger que previene eliminaciones
CREATE OR REPLACE TRIGGER T11 
BEFORE DELETE ON InteresEn 
FOR EACH ROW 
BEGIN    
    RAISE_APPLICATION_ERROR(
        -20001, 
        'No se permite eliminar registros de InteresEn. La relaci�n entre ubicaci�n y demanda debe mantenerse.'
    ); 
END;

/*DisparadorOk*/
INSERT INTO Ubicaciones VALUES ('UB001', -74, 485, 'Bogota', 'Norte', 'Chapinero');
INSERT INTO InteresEn VALUES('UB001', 'D001', 'Alto');
SELECT * FROM Ubicaciones;
SELECT * FROM Demandas;
/*Disparador No Ok*/
UPDATE InteresEn 
SET nivel = 'Bajo' 
WHERE codigoUbicacion = 'UB001' AND numeroDemanda = 'D001';

-- Intento de eliminaci�n (activar� T11):
DELETE FROM InteresEn 
WHERE codigoUbicacion = 'UB001' AND numeroDemanda = 'D001';

DROP TRIGGER T10;
DROP TRIGGER T11;


-------/*ELIMINAR*/-------
---Únicamente se pueden eliminar, si es la ultima demanda.
 
CREATE OR REPLACE TRIGGER T12
BEFORE DELETE ON Demandas
FOR EACH ROW
DECLARE
    num NUMBER;
BEGIN
    SELECT COUNT(*) INTO num FROM demandas WHERE idusuario = :OLD.idusuario;
    IF num > :OLD.numero THEN
        RAISE_APPLICATION_ERROR(-20003,'Solo se puede eliminar si es la ultima demanda.');
    END IF;
END;

/*Disparador Ok*/
INSERT INTO Demandas VALUES(
    '10001', 'D007', SYSDATE, 'Casa', 190000000
);
SELECT * FROM DEMANDAS;
/*Disparador No Ok*/
DELETE FROM Demandas WHERE numero = '98765' AND idusuario = '10001';
SELECT * FROM DEMANDAS;
DROP TRIGGER T12;

/*LAB 05*/

SELECT * FROM mbda.data;
SELECT * FROM Usuarios ;

/*
    INSERT INTO mbda.data VALUES ('julian.lopez-b@mail.escuelaing.edu.co',3187063281,NULL,1000100419,'Julian Lopez','Escuela Colombiana De Ingeniera');
    INSERT INTO mbda.data VALUES ('tulio.riano-s@mail.escuelaing.edu.co',3167690706,NULL,1000099099,'Tulio Riaño','Escuela Colombiana De Ingeniera');
    UPDATE mbda.data SET nombres = 'Camilo Lopez' WHERE contacto1 = 3187063281;
    DELETE mbda.data WHERE contacto1 = 3187063281;
    SELECT count(*)  FROM  mbda.data WHERE razon is not NULL;
    SELECT count(*)  FROM  mbda.data WHERE nombres is not NULL and razon IS NULL and razon not like '%null%' or razon not like '%NULL%';
*/
CREATE SEQUENCE seq_id_usuarios
START WITH 1
INCREMENT BY 1
NOCACHE;


DROP SEQUENCE seq_id_usuarios;



INSERT INTO Usuarios (id, fechaRegistro, correoElectronico)
SELECT 
    'LT' || TO_CHAR(seq_id_usuarios.NEXTVAL, 'FM000') AS id, 
    SYSDATE AS fechaRegistro,
    CORREO
FROM (
    SELECT DISTINCT CORREO
    FROM mbda.data
) subquery
WHERE CORREO IS NOT NULL 
AND NOT EXISTS (
    SELECT 1 
    FROM Usuarios 
    WHERE correoElectronico = subquery.CORREO
);

SELECT * FROM Usuarios;
/*IMPORTAR A PERSONANATURALES*/
INSERT INTO PersonaNaturales (tipoDocumento, numeroDocumento, nombres, nacionalidad, idusuario)
SELECT 
    'CC',                       
    NUMERO,                       
    NOMBRES,                      
    'Colombiano',                 
    (SELECT id 
     FROM Usuarios 
     WHERE correoElectronico = mbda.data.CORREO 
     AND ROWNUM = 1) 
FROM mbda.data             
WHERE NOMBRES IS NOT NULL AND RAZON IS NULL;

/*IMPORTAR A EMPRESAS*/
CREATE SEQUENCE seq_NIT
START WITH 1
INCREMENT BY 1
NOCACHE;

DROP SEQUENCE seq_NIT;

INSERT INTO Empresas (nit, razonSocial, idusuario)
SELECT 
    TO_CHAR(seq_NIT.NEXTVAL, 'FM00000000') || '-1',
    RAZON,
    (SELECT id FROM Usuarios WHERE correoElectronico = mbda.data.CORREO AND ROWNUM = 1)
FROM mbda.data 
WHERE RAZON IS NOT NULL 
AND NOMBRES IS NULL;

/*IMPORTAR A NUMEROSCONTACTOS*/

INSERT INTO numerosContactos (numeroContacto, idusuario)
SELECT 
    CONTACTO1, 
    (SELECT id FROM Usuarios WHERE correoElectronico = mbda.data.CORREO AND ROWNUM = 1)
FROM mbda.data
WHERE NOT EXISTS (                
    SELECT 1 
    FROM numerosContactos 
    WHERE numeroContacto = mbda.data.CONTACTO1
);

--4

SELECT OWNER , OBJECT_NAME , OBJECT_TYPE
FROM ALL_OBJECTS
WHERE OBJECT_NAME  = 'DATA'
    AND OBJECT_TYPE = 'TABLE';
    
--Paquete Crud

--PC_OFERTAS
CREATE OR REPLACE PACKAGE PC_OFERTAS IS
    PROCEDURE AD_OFERTA(x_codigoUbicacion IN VARCHAR, x_numero IN NUMBER, x_fecha IN DATE, x_direccion IN VARCHAR, x_tipoVivienda IN VARCHAR, x_costo IN NUMBER, x_anexos IN VARCHAR, x_estado IN VARCHAR, x_idUsuario IN VARCHAR);
    PROCEDURE AD_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR);
    PROCEDURE DEL_FOTOGRAFIAS(x_nombre IN VARCHAR);
    PROCEDURE MO_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR);
    PROCEDURE DEL_OFERTAS(x_numero IN NUMBER);
    PROCEDURE DEL_OPCIONCREDITO(x_numeroOferta IN NUMBER);
    PROCEDURE MO_OPCIONCREDITO(x_plazo IN NUMBER, x_valorMensual IN NUMBER, x_numeroOferta IN NUMBER);
    FUNCTION CO_USUARIO_OFERTAS RETURN SYS_REFCURSOR;

END PC_OFERTAS;

--Cuerpo Crud
CREATE OR REPLACE PACKAGE BODY PC_OFERTAS IS

    PROCEDURE AD_OFERTA(x_codigoUbicacion IN VARCHAR, x_numero IN NUMBER, x_fecha IN DATE, x_direccion IN VARCHAR, x_tipoVivienda IN VARCHAR, x_costo IN NUMBER, x_anexos IN VARCHAR, x_estado IN VARCHAR, x_idusuario IN VARCHAR) IS
    BEGIN
        INSERT INTO Ofertas(codigoUbicacion, numero,fecha, direccion, tipoVivienda, costo, anexos, estado, idusuario) VALUES (x_codigoUbicacion, x_numero, x_fecha, x_direccion, x_tipoVivienda, x_costo, x_anexos, x_estado, x_idusuario);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20101, 'Error al generar Oferta');
    END;

    PROCEDURE AD_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR) IS
    BEGIN 
        INSERT INTO Fotografias(nombre,ruta,descripcion) VALUES (x_nombre,x_ruta,x_descripcion);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20100, 'Error No se Pueden Adicionar Fotografias');
    END;

    PROCEDURE DEL_FOTOGRAFIAS(x_nombre IN VARCHAR) IS
    BEGIN 
        DELETE FROM Fotografias WHERE nombre = x_nombre;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20102, 'Error al eliminar en Fotografias');
    END;    

    PROCEDURE MO_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR) IS 
    BEGIN 
        UPDATE Fotografias SET ruta  = x_ruta , descripcion = x_descripcion WHERE nombre = x_nombre ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN 
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20103, 'Error al modificar en Fotografias');
    END;

    PROCEDURE DEL_OFERTAS(x_numero IN NUMBER) IS
    BEGIN 
        DELETE FROM Ofertas WHERE numero = x_numero; 
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20104, 'Error al eliminar en Ofertas');
    END;

    PROCEDURE DEL_OPCIONCREDITO(x_numeroOferta IN NUMBER) IS
    BEGIN 
        DELETE FROM OpcionesCreditos WHERE numeroOferta = x_numeroOferta; 
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20105, 'Error al eliminar en OpcionCredito');
    END;

    PROCEDURE MO_OPCIONCREDITO(x_plazo IN NUMBER, x_valorMensual IN NUMBER, x_numeroOferta IN NUMBER) IS
    BEGIN 
        UPDATE OpcionesCreditos SET plazo = x_plazo , valorMensual = x_valorMensual WHERE numeroOferta = x_numeroOferta;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN 
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20106, 'Error al modificar en Opcion De Credito');
    END;
    
    FUNCTION CO_USUARIO_OFERTAS RETURN SYS_REFCURSOR IS
        cur_ofertas SYS_REFCURSOR;
    BEGIN
        OPEN cur_ofertas FOR
            SELECT idusuario, COUNT(numero) AS Ofertas
            FROM Ofertas
            GROUP BY idusuario;
        RETURN cur_ofertas;
    END CO_USUARIO_OFERTAS;
    
END PC_OFERTAS;


--CRUD OK

-- AD_OFERTA
INSERT INTO Usuarios VALUES ('10052',TO_DATE('12-SEP-2022 19:55:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario52@gmail.com'); 
INSERT INTO Ubicaciones VALUES ('1111123', -12, 85, 'Chia', 'Oriente', 'Eglesia');

BEGIN
    INSERT INTO Ofertas (codigoUbicacion, numero, fecha, direccion, tipoVivienda, costo, anexos, estado, idusuario) VALUES ('1111123', 987 ,TO_DATE('2024/09/25', 'yyyy/mm/dd'),'Calle 57', 'Doble', 999, 'Anexos', 'Aprobado', '10052');
    COMMIT;
END;
-- AD_FOTOGRAFIAS 
BEGIN 
    INSERT INTO Fotografias(nombre,ruta, descripcion) VALUES ('Paco','/imagen/foto4.jpg','Vista Frontal Casa');
    COMMIT;
END;
-- MO_FOTOGRAFIAS
BEGIN
    PC_OFERTAS.MO_FOTOGRAFIAS('Paco','/ViajeImagenes/foto1.jpg','Vista Playa');
    DBMS_OUTPUT.PUT_LINE('Tanto ruta como estado cambiados exitosamente');
END;
-- DEL_FOTOGRAFIAS

BEGIN
    PC_OFERTAS.DEL_FOTOGRAFIAS('Paco');
    DBMS_OUTPUT.PUT_LINE('Nombre de fotografia eliminado');
END;

-- DEL_OFERTAS
BEGIN
    PC_OFERTAS.DEL_OFERTAS(987);
    DBMS_OUTPUT.PUT_LINE('Oferta eliminada exitosamente');
END;
-- DEL_OPCIONCREDITO
BEGIN
    PC_OFERTAS.DEL_OPCIONCREDITO(987);
    DBMS_OUTPUT.PUT_LINE('Eliminado exitosamente de opción crédito');
END;
-- AD_FOTOGRAFIAS
BEGIN
    PC_OFERTAS.AD_FOTOGRAFIAS('Foto1','/ruta/fotoapto.jpg','Fotodelapartamento');
    DBMS_OUTPUT.PUT_LINE('Se agrego la fotografia');
END;

--CRUD NO OK
BEGIN
    PC_OFERTAS.AD_OFERTA('11123', 987 ,TO_DATE('2024/09/25', 'yyyy/mm/dd'),'Calle 57', 'Doble', 999, 'Anexos', 'Aprobado', '10052');
    DBMS_OUTPUT.PUT_LINE('Error al insertar');
END;

BEGIN
    PC_OFERTAS.MO_OPCIONCREDITO(13,'cincuenta millones',1);
    DBMS_OUTPUT.PUT_LINE('La actualizacion fue exitosa');
END;

BEGIN
    PC_OFERTAS.AD_FOTOGRAFIAS('Foto1','/ruta/fotoapto.jpg','Fotodelapartamento');
    DBMS_OUTPUT.PUT_LINE('Se agrego la fotografia');
END;

--CRUDEX
DROP PACKAGE BODY PC_OFERTAS;
DROP PACKAGE PC_OFERTAS;
/*PC_DEMANDAS*/
CREATE OR REPLACE PACKAGE PC_DEMANDAS IS
    PROCEDURE AD_DEMANDAS(x_idusuario IN VARCHAR, x_numero IN NUMBER ,x_fecha IN DATE , x_tipoVivienda IN VARCHAR , x_maxCompra IN NUMBER);
    PROCEDURE AD_UBICACION_INTERES(x_codigoUbicacion IN VARCHAR, x_numeroDemanda IN VARCHAR, x_nivel IN VARCHAR);
    PROCEDURE MO_ORIGENFONDOS(x_numeroDemanda IN VARCHAR, x_estaAprobado IN VARCHAR);
    PROCEDURE DEL_DEMANDAS(x_numero IN NUMBER);
    FUNCTION CO_DEMANDAS_VIVIENDAS RETURN SYS_REFCURSOR;
 
END PC_DEMANDAS;

/*Cuerpo */
CREATE OR REPLACE PACKAGE BODY PC_DEMANDAS IS
    PROCEDURE AD_DEMANDAS(x_idusuario IN VARCHAR, x_numero IN NUMBER, x_fecha IN DATE, x_tipoVivienda IN VARCHAR, x_maxCompra IN NUMBER) IS
    BEGIN
        INSERT INTO Demandas(idusuario, numero, fecha, tipoVivienda, maxCompra) VALUES (x_idusuario, x_numero,x_fecha,x_tipoVivienda,x_maxCompra);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20107, 'Error al Insertar En Demandas');
    END;
 
    PROCEDURE AD_UBICACION_INTERES(x_codigoUbicacion IN VARCHAR, x_numeroDemanda IN VARCHAR , x_nivel IN VARCHAR) IS
    BEGIN
        INSERT INTO InteresEn(codigoUbicacion, numeroDemanda, nivel) VALUES (x_codigoUbicacion, x_numeroDemanda, x_nivel);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20108, 'Error al Insertar En Ubicacion Interes');
    END;
 
    PROCEDURE MO_ORIGENFONDOS(x_numeroDemanda IN VARCHAR, x_estaAprobado IN VARCHAR) IS
    BEGIN
        UPDATE ORIGENFONDOS SET estaAprobado = x_estaAprobado WHERE numeroDemanda = x_numeroDemanda;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20109, 'Error al modificar en OrigenFondos');
    END;
 
    PROCEDURE DEL_DEMANDAS(x_numero IN NUMBER) IS
    BEGIN
        DELETE FROM Demandas WHERE numero = x_numero;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20110, 'Error al eliminar en Demandas');
    END;
 
    
    FUNCTION CO_DEMANDAS_VIVIENDAS RETURN SYS_REFCURSOR IS
        cur_demandas_viviendas SYS_REFCURSOR;
    BEGIN
        OPEN cur_demandas_viviendas FOR
            SELECT numero, tipoVivienda, maxCompra
            FROM Demandas;
        RETURN cur_demandas_viviendas;
    END CO_DEMANDAS_VIVIENDAS;
    
END PC_DEMANDAS;

/*DROP PC_DEMANDA*/
DROP PACKAGE PC_DEMANDAS;


/*PC_UBICACION*/
CREATE OR REPLACE PACKAGE PC_UBICACION IS
    PROCEDURE AD_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR);
    PROCEDURE MO_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR);
    PROCEDURE DEL_UBICACION(x_codigo IN VARCHAR);
    FUNCTION CO_UBICACION RETURN SYS_REFCURSOR;

END PC_UBICACION;
-- Cuerpo
CREATE OR REPLACE PACKAGE BODY PC_UBICACION IS
    PROCEDURE AD_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR) IS
    BEGIN
        INSERT INTO Ubicaciones(codigo,latitud,longitud,ciudad,zona,barrio) VALUES (x_codigo, x_latitud, x_longitud, x_ciudad, x_zona, x_barrio);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20111, 'Error al insertar ubicaci�n');
    END;
    
    PROCEDURE MO_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR) IS
    BEGIN
        UPDATE Ubicaciones SET latitud = x_latitud, longitud = x_longitud, ciudad = x_ciudad, zona = x_zona, barrio = x_barrio WHERE codigo = x_codigo;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20112, 'Error al modificar ubicaci�n');
    END;
    
    PROCEDURE DEL_UBICACION(x_codigo IN VARCHAR) IS
    BEGIN
        DELETE FROM Ubicaciones
        WHERE codigo = x_codigo;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20113, 'Error al eliminar ubicaci�n');
    END;
        
    FUNCTION CO_UBICACION RETURN SYS_REFCURSOR IS
        cur_ubicacion SYS_REFCURSOR;
    BEGIN
        OPEN cur_ubicacion FOR
            SELECT latitud, longitud, ciudad, zona, barrio
            FROM Ubicaciones;
        RETURN cur_ubicacion;
    END CO_UBICACION;

END PC_UBICACION;

DROP PACKAGE PC_UBICACION;

/*PC_USUARIO*/
CREATE OR REPLACE PACKAGE PC_USUARIO IS
    PROCEDURE AD_USUARIO(x_id IN VARCHAR, x_fechaRegistro IN DATE, x_correoElectronico IN VARCHAR);
    FUNCTION CO_USUARIO RETURN SYS_REFCURSOR;
END PC_USUARIO;
    
CREATE OR REPLACE PACKAGE BODY PC_USUARIO IS

    PROCEDURE AD_USUARIO(x_id IN VARCHAR, x_fechaRegistro IN DATE, x_correoElectronico IN VARCHAR) IS
    BEGIN
        INSERT INTO Usuarios(id,fechaRegistro,correoElectronico) VALUES (x_id, x_fechaRegistro, x_correoElectronico);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20114, 'Error al insertar usuario');
    END;
    
    FUNCTION CO_USUARIO RETURN SYS_REFCURSOR IS
        cur_usuario SYS_REFCURSOR;
    BEGIN
        OPEN cur_usuario FOR
            SELECT Usuarios.id, Usuarios.fechaRegistro, Usuarios.correoElectronico, COUNT(Ofertas.idusuario)
            FROM Usuarios
            JOIN Ofertas ON Usuarios.id = Ofertas.idusuario
            GROUP BY Usuarios.id, Usuarios.fechaRegistro, Usuarios.correoElectronico
            ORDER BY Ofertas.idusuario DESC;
        RETURN cur_usuario;
    END CO_USUARIO;
    
END PC_USUARIO;

--ActoresE
CREATE OR REPLACE PACKAGE PA_Analista IS
    PROCEDURE AD_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR);
    PROCEDURE MO_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR);
    PROCEDURE DEL_UBICACION(x_codigo IN VARCHAR);
    FUNCTION CO_UBICACION RETURN SYS_REFCURSOR;
END PA_Analista;

CREATE OR REPLACE PACKAGE PA_Usuario IS
    PROCEDURE AD_OFERTA(x_codigoUbicacion IN VARCHAR, x_numero IN NUMBER, x_fecha IN DATE, x_direccion IN VARCHAR, x_tipoVivienda IN VARCHAR, x_costo IN NUMBER, x_anexos IN VARCHAR, x_estado IN VARCHAR, x_idusuario IN VARCHAR);
    PROCEDURE AD_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR);
    PROCEDURE DEL_FOTOGRAFIAS(x_nombre IN VARCHAR);
    PROCEDURE MO_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR);
    PROCEDURE DEL_OFERTAS(x_numero IN NUMBER);
    PROCEDURE DEL_OPCIONCREDITO(x_numeroOferta IN NUMBER);
    PROCEDURE MO_OPCIONCREDITO(x_plazo IN NUMBER, x_valorMensual IN NUMBER, x_numeroOferta IN NUMBER);
    PROCEDURE AD_USUARIO(x_id IN VARCHAR, x_fechaRegistro IN DATE, x_correoElectronico IN VARCHAR);
    FUNCTION CO_USUARIO_OFERTAS RETURN SYS_REFCURSOR;
    FUNCTION  CO_USUARIO RETURN SYS_REFCURSOR;
    PROCEDURE AD_DEMANDAS(x_idusuario IN VARCHAR, x_numero IN NUMBER ,x_fecha IN DATE , x_tipoVivienda IN VARCHAR , x_maxCompra IN NUMBER);
    PROCEDURE AD_UBICACION_INTERES(x_codigoUbicacion IN VARCHAR, x_numeroDemanda IN VARCHAR, x_nivel IN VARCHAR);
    PROCEDURE MO_ORIGENFONDOS(x_numeroDemanda IN VARCHAR, x_estaAprobado IN VARCHAR);
    PROCEDURE DEL_DEMANDAS(x_numero IN NUMBER);
    FUNCTION CO_DEMANDAS_VIVIENDAS RETURN SYS_REFCURSOR;
    
END PA_Usuario;
--ActoresI
CREATE OR REPLACE PACKAGE BODY PA_Analista IS
    PROCEDURE AD_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR) IS
        BEGIN
         PC_UBICACION.AD_UBICACION(x_codigo,x_latitud,x_longitud,x_ciudad,x_zona,x_barrio);
        END;
    PROCEDURE MO_UBICACION(x_codigo IN VARCHAR, x_latitud IN NUMBER, x_longitud IN NUMBER, x_ciudad IN VARCHAR, x_zona IN VARCHAR, x_barrio IN VARCHAR) IS
        BEGIN
        PC_UBICACION.MO_UBICACION(x_codigo, x_latitud, x_longitud, x_ciudad, x_zona, x_barrio);
        END;
    PROCEDURE DEL_UBICACION(x_codigo IN VARCHAR) is
        BEGIN
        PC_UBICACION.DEL_UBICACION(x_codigo);
        END;
    FUNCTION CO_UBICACION RETURN SYS_REFCURSOR IS CO_UBI SYS_REFCURSOR;
    BEGIN
        CO_UBI := PC_UBICACION.CO_UBICACION;
        RETURN CO_UBI;
    END;
END PA_Analista;

CREATE OR REPLACE PACKAGE BODY PA_Usuario IS
    PROCEDURE AD_OFERTA(x_codigoUbicacion IN VARCHAR, x_numero IN NUMBER, x_fecha IN DATE, x_direccion IN VARCHAR, x_tipoVivienda IN VARCHAR, x_costo IN NUMBER, x_anexos IN VARCHAR, x_estado IN VARCHAR, x_idusuario IN VARCHAR) IS
        BEGIN
        PC_OFERTAS.AD_OFERTA(x_codigoUbicacion, x_numero, x_fecha, x_direccion, x_tipoVivienda, x_costo, x_anexos, x_estado, x_idusuario);
        END;
    PROCEDURE AD_FOTOGRAFIAS(x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR) IS
        BEGIN
        PC_OFERTAS.AD_FOTOGRAFIAS(x_nombre,x_ruta,x_descripcion);
        END;
    PROCEDURE DEL_FOTOGRAFIAS(x_nombre IN VARCHAR) IS
        BEGIN
        PC_OFERTAS.DEL_FOTOGRAFIAS(x_nombre);
        END;
    PROCEDURE MO_FOTOGRAFIAS (x_nombre IN VARCHAR, x_ruta IN VARCHAR,x_descripcion IN VARCHAR) IS
        BEGIN
        PC_OFERTAS.MO_FOTOGRAFIAS(x_nombre,x_ruta,x_descripcion);
        END;
    PROCEDURE DEL_OFERTAS(x_numero IN NUMBER) IS
        BEGIN
        PC_OFERTAS.DEL_OFERTAS(x_numero);
        END;
    PROCEDURE DEL_OPCIONCREDITO(x_numeroOferta IN NUMBER) IS
        BEGIN
        PC_OFERTAS.DEL_OPCIONCREDITO(x_numeroOferta);
        END;
    PROCEDURE MO_OPCIONCREDITO(x_plazo IN NUMBER, x_valorMensual IN NUMBER, x_numeroOferta IN NUMBER) IS
        BEGIN
        PC_OFERTAS.MO_OPCIONCREDITO(x_plazo, x_valorMensual, x_numeroOferta);
        END;
    PROCEDURE AD_USUARIO(x_id IN VARCHAR, x_fechaRegistro IN DATE, x_correoElectronico IN VARCHAR) IS
        BEGIN
        PC_USUARIO.AD_USUARIO(x_id, x_fechaRegistro, x_correoElectronico);
        END;
    FUNCTION CO_USUARIO_OFERTAS RETURN SYS_REFCURSOR IS CO_U1 SYS_REFCURSOR;
    BEGIN
        CO_U1 := PC_OFERTAS.CO_USUARIO_OFERTAS;
        RETURN CO_U1;
    END;
    FUNCTION CO_USUARIO RETURN SYS_REFCURSOR IS CO_USU1 SYS_REFCURSOR;
    BEGIN
        CO_USU1 := PC_USUARIO.CO_USUARIO;
        RETURN CO_USU1;
    END;
    
    PROCEDURE AD_DEMANDAS(x_idusuario IN VARCHAR, x_numero IN NUMBER ,x_fecha IN DATE , x_tipoVivienda IN VARCHAR , x_maxCompra IN NUMBER) IS
    BEGIN
        PC_DEMANDAS.AD_DEMANDAS(x_idusuario, x_numero, x_fecha, x_tipoVivienda, x_maxCompra);
    END;

    PROCEDURE AD_UBICACION_INTERES(x_codigoUbicacion IN VARCHAR, x_numeroDemanda IN VARCHAR, x_nivel IN VARCHAR) IS
    BEGIN
        PC_DEMANDAS.AD_UBICACION_INTERES(x_codigoUbicacion, x_numeroDemanda, x_nivel);
    END;
    
    PROCEDURE MO_ORIGENFONDOS(x_numeroDemanda IN VARCHAR, x_estaAprobado IN VARCHAR) IS
    BEGIN
        PC_DEMANDAS.MO_ORIGENFONDOS(x_numeroDemanda, x_estaAprobado);
    END;
    
    PROCEDURE DEL_DEMANDAS(x_numero IN NUMBER) IS
    BEGIN
        PC_DEMANDAS.DEL_DEMANDAS(x_numero);
    END;
    
    FUNCTION CO_DEMANDAS_VIVIENDAS RETURN SYS_REFCURSOR IS CO_DE1 SYS_REFCURSOR;
    BEGIN
        CO_DE1 := PC_DEMANDAS.CO_DEMANDAS_VIVIENDAS;
        RETURN CO_DE1;
    END;
    
END PA_Usuario;

DROP PACKAGE PA_USUARIO;

/* Seguridad */ 
CREATE ROLE Usuario_Seguridad;
CREATE ROLE Administradores_Seguridad;
GRANT EXECUTE ON PA_USUARIO TO Usuario_Seguridad;
GRANT EXECUTE ON PA_ANALISTA TO Administradores_Seguridad;

GRANT Usuario_Seguridad TO bd1000100419;
GRANT Administradores_Seguridad TO bd1000100444;

/* XSeguridad */
DROP ROLE Usuario_Seguridad;
DROP ROLE Administradores_Seguridad;

/*Seguridad Ok*/
INSERT INTO Usuarios VALUES ('10004',TO_DATE('2005/09/25', 'yyyy/mm/dd'),'usuario04@gmail.com');
INSERT INTO Ubicaciones VALUES ('18235432100', -74, 485, 'Bogota', 'Norte', 'Chapinero');
BEGIN
    PA_Usuario.AD_OFERTA('18235432100', 810, TO_DATE('2024/09/25', 'yyyy/mm/dd'), 'Calle 123 #45-67', 'Bodega', 450000000, NULL, 'Pendiente', '10004');
END;

BEGIN 
    PA_Usuario.AD_Fotografias('Foto6', '/imagenes/foto6.jpg', 'Vista Lateral de la propiedad');
END;

BEGIN
    PA_Analista.MO_Ubicacion('77765432100', -44, 120, 'Sopo', 'Central', 'Alpina');
END;

BEGIN
    PA_Analista.AD_Ubicacion('77765432100', -74, 485, 'Bogota', 'Norte', 'Chapinero');
END;

BEGIN
    PA_Analista.DEL_Ubicacion('77765432100');
END;

/*Seguridad No Ok*/
/*El codigo ubicaci�n es diferente al que se quiere insertar en oferta*/
INSERT INTO Usuarios VALUES ('10019',TO_DATE('2005/09/25', 'yyyy/mm/dd'),'usuario19@gmail.com');
INSERT INTO Ubicaciones VALUES ('38765432100', -74, 485, 'Bogota', 'Norte', 'Chapinero');


DELETE FROM Usuarios WHERE id = '10009';

SELECT * FROM Usuarios;
SELECT * FROM Ubicaciones;

BEGIN
    PA_Usuario.AD_OFERTA('12765432100', 67890, TO_DATE('2024/09/25', 'yyyy/mm/dd'), 'Calle 123 #45-67', 'Bodega', 450000000, NULL, 'Pendiente', '10019');
END;
/*No se puede adicionar una fotograf�a que ya existe*/

BEGIN
    PA_USUARIO.AD_Fotografias('Foto6', '/imagenes/foto6.jpg', 'Vista Lateral de la propiedad');
END;

/*No se puede adicionar una ubicaci�n que ya existe*/

BEGIN
    PA_Analista.AD_Ubicacion('77765432100', -74, 485, 'Bogota', 'Norte', 'Chapinero');
END;



------------------------------- PRUEBAS -------------------------------------------------
-- Camilo quiero a�adir unas fotografias sobre unas viviendas
-- 1. Para esto, se necesita insertar la informaci�n sobre la fotograf�a
BEGIN 
    PC_OFERTAS.AD_FOTOGRAFIAS('FachadaCasa','/fotos/CasaFachada.jpg','Foto Principal');
END;
-- 2. Camilo quiere modificar la fotografia el cual su direccion y descripcion diferente
BEGIN
    PC_OFERTAS.MO_FOTOGRAFIAS('FachadaCasa','/fotos/CasaFachadaNueva.jpg','Fachada principal renovada');
END;

-- 3. Camilo quiere adicionar una nueva ubicacion
BEGIN
    PC_UBICACION.AD_UBICACION('99999456', 321, 10, 'Bogot� ', 'Campin', 'Nicolas');
END;
-- 4. Camilo se acaba de dar cuenta que inserto mal los datos y necesita eliminar estos
BEGIN
    PC_UBICACION.DEL_UBICACION('99999456');
END;
-- 5. De la misma manera necesita eliminar las fotografias asociadas
BEGIN
    PC_OFERTAS.DEL_FOTOGRAFIAS('FachadaCasa');
END;

-- 6. Respecto a esto el analista quiere adicionar la ubicaci�n que camilo inserto mal
BEGIN
    PA_ANALISTA.AD_UBICACION('1232321', -14, 85, 'Bogota', 'Centro', 'Aguas');
END;

-- 7. Ahora como camilo no pudo realizarla el analista quiere asegurarse de que la ubicaci�n este
DECLARE
    cursor_prueba SYS_REFCURSOR;
BEGIN
    cursor_prueba := PA_ANALISTA.CO_UBICACION();
    DBMS_SQL.RETURN_RESULT(cursor_prueba);
END;

-- 8. Debido a que camilo no pudo realizar la respectiva inserci�n le toca primero insertarse como Usuario
BEGIN
    PA_USUARIO.AD_USUARIO('6565', SYSDATE,'camilo2005@gmail.com');
END;

-- 9. Camilo realiza una demanda para un tipo de vivienda que sea penthouse
BEGIN
    PA_USUARIO.AD_DEMANDAS('6565', '7876', SYSDATE, 'Penthouse', 900000);
END;

-- 10. Finalizado esto, queremos consultar la demanda del penthouse con respecto a su ubicacion
DECLARE
    cursor_penthouse SYS_REFCURSOR;
BEGIN
    OPEN cursor_penthouse FOR
        SELECT d.numero AS numero_demanda,
               d.tipoVivienda,
               d.maxCompra,
               u.latitud,
               u.longitud,
               u.ciudad,
               u.zona,
               u.barrio
        FROM Demandas d
        JOIN Ubicaciones u ON d.idusuario = u.codigo
        WHERE d.tipoVivienda = 'Penthouse';

    DBMS_SQL.RETURN_RESULT(cursor_penthouse);
END;

/*XPoblar*/
DELETE FROM Usuarios;
DELETE FROM PersonaNaturales;
DELETE FROM Empresas;
DELETE FROM Demandas;
DELETE FROM Avisos;
DELETE FROM OrigenFondos;
DELETE FROM InteresEn;
DELETE FROM Ofertas;
DELETE FROM Fotografias;
DELETE FROM PermiteFotografias;
DELETE FROM OpcionesCreditos;
DELETE FROM Ubicaciones;
DELETE FROM Notificaciones;
DELETE FROM Alertas;

/*xTablas*/
DROP TABLE Usuarios CASCADE CONSTRAINTS;
DROP TABLE PersonaNaturales CASCADE CONSTRAINTS;
DROP TABLE Empresas CASCADE CONSTRAINTS;
DROP TABLE Demandas CASCADE CONSTRAINTS;
DROP TABLE Avisos CASCADE CONSTRAINTS;
DROP TABLE OrigenFondos CASCADE CONSTRAINTS;
DROP TABLE InteresEn CASCADE CONSTRAINTS;
DROP TABLE Ofertas CASCADE CONSTRAINTS;
DROP TABLE Fotografias CASCADE CONSTRAINTS;
DROP TABLE PermiteFotografias CASCADE CONSTRAINTS;
DROP TABLE OpcionesCreditos CASCADE CONSTRAINTS;
DROP TABLE Ubicaciones CASCADE CONSTRAINTS;
DROP TABLE Alertas CASCADE CONSTRAINTS;
DROP TABLE Notificaciones CASCADE CONSTRAINTS;
DROP TABLE numerosContactos CASCADE CONSTRAINTS;


