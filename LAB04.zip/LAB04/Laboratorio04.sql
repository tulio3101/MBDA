/*Tablas*/
CREATE TABLE Usuarios(
             id VARCHAR(5) NOT NULL, 
             fechaRegistro DATE NOT NULL, 
             correoElectronico VARCHAR(50) NOT NULL, 
             numerosContacto VARCHAR(10) NOT NULL);
             
CREATE TABLE PersonaNaturales(
             tipoDocumento VARCHAR(25), 
             numeroDocumento VARCHAR(25),
             nombres VARCHAR(20) NOT NULL, 
             nacionalidad varchar(10) NOT NULL, 
             idusuario VARCHAR(5)NOT NULL);
             
CREATE TABLE Empresas(
             nit VARCHAR(10), 
             razonSocial VARCHAR(100) NOT NULL, 
             idusuario VARCHAR(5)NOT NULL);

CREATE TABLE Demandas(
             idusuario VARCHAR(5)NOT NULL, 
             numero VARCHAR(5)NOT NULL, 
             fecha DATE NOT NULL, 
             tipoVivienda VARCHAR(25) NOT NULL, 
             maxCompra NUMBER NOT NULL);
             
CREATE TABLE Avisos(
             numeroDemanda VARCHAR(5)NOT NULL, 
             id VARCHAR(5) NOT NULL, 
             fechaCreacion DATE NOT NULL, 
             mensaje VARCHAR(30) NOT NULL, 
             estado VARCHAR(10) NOT NULL, 
             usuario VARCHAR(25) NOT NULL);
             
CREATE TABLE OrigenFondos(
             numeroDemanda VARCHAR(5)NOT NULL, 
             valor NUMBER NOT NULL, 
             credito VARCHAR(15) NOT NULL, 
             estaAprobado VARCHAR(15) NULL);
             
CREATE TABLE InteresEn(
             codigoUbicacion VARCHAR(11) NOT NULL, 
             numeroDemanda VARCHAR(5)NOT NULL ,
             nivel VARCHAR(25) NOT NULL );

CREATE TABLE Ofertas(
            codigoUbicacion VARCHAR(11) NOT NULL, 
            numero VARCHAR(5) NOT NULL,
            fecha DATE NOT NULL,
            direccion VARCHAR(50) NOT NULL,
            tipoVivienda VARCHAR(25) NOT NULL,
            costo NUMBER NOT NULL,
            anexos VARCHAR(25) NULL,
            estado VARCHAR(25) NOT NULL,
            idusuario VARCHAR(5)NOT NULL);
            
CREATE TABLE Fotografias(
             nombre VARCHAR(15) NOT NULL, 
             ruta VARCHAR(100) NOT NULL, 
             descripcion VARCHAR(100) NOT NULL);
             
CREATE TABLE PermiteFotografias(
             numeroOferta VARCHAR(5)NOT NULL,
             nombreFotografia VARCHAR(15) NOT NULL);
             
CREATE TABLE OpcionesCreditos(
             plazo NUMBER NOT NULL,
             valorMensual NUMBER NOT NULL,
             numeroOferta VARCHAR(5)NOT NULL);

CREATE TABLE Ubicaciones(
             codigo VARCHAR(11) NOT NULL,
             latitud NUMBER(3) NOT NULL ,
             longitud NUMBER(3) NOT NULL,
             ciudad VARCHAR(10) NOT NULL,
             zona VARCHAR(25) NOT NULL ,
             barrio VARCHAR(10) NOT NULL);
             
CREATE TABLE Alertas(
    idAlertas VARCHAR(5) NOT NULL,
    fechaCreacion DATE NOT NULL,
    mensaje VARCHAR(30) NOT NULL,
    estado VARCHAR(10) NOT NULL,
    usuario VARCHAR(25) NOT NULL,
    alertaEstado VARCHAR(15) NOT NULL,
    hora DATE NOT NULL,
    datos VARCHAR(25) NOT NULL
    );

CREATE TABLE Notificaciones(
    idNotificaciones VARCHAR(5) NOT NULL,
    fechaCreacion DATE NOT NULL,
    mensaje VARCHAR(30) NOT NULL,
    estado VARCHAR(30) NOT NULL,
    usuario VARCHAR(25) NOT NULL
    );


/*PoblarOK*/
INSERT INTO Usuarios VALUES ('10001',TO_DATE('28-SEP-2024 20:55:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario01@gmail.com','3124338358');
INSERT INTO Usuarios VALUES ('10002',TO_DATE('04-FEB-2024 18:05:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario02@gmail.com','3235207883');
INSERT INTO Usuarios VALUES ('10003',TO_DATE('13-OCT-2024 10:13:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario03@gmail.com','3128941248');

INSERT INTO PersonaNaturales VALUES ('Cedula', '1234567', 'Juan', 'Colombiana','10001');
INSERT INTO PersonaNaturales VALUES ('Cedula', '7654321', 'Maria', 'Mexicana','10002');
INSERT INTO PersonaNaturales VALUES ('Cedula', '9876543', 'Pedro', 'Argentino','10003');

INSERT INTO Empresas VALUES ('95687568-3','Empresa P?blica de Telecomunicaciones de Colombia S.A.','10001');
INSERT INTO Empresas VALUES ('12374471-2','Comercial Mexicana de Pinturas S.A. de C.V.','10002');
INSERT INTO Empresas VALUES ('28145672-5','Aerol?neas Argentinas S.A.','10003');

INSERT INTO Demandas VALUES ('10001','98765',TO_DATE('2024/09/22','yyyy/mm/dd'),'Bodega',400000000);
INSERT INTO Demandas VALUES ('10001','45678',TO_DATE('2024/04/12','yyyy/mm/dd'),'Apartamento',1005690);
INSERT INTO Demandas VALUES ('10003','12365',TO_DATE('2024/06/04','yyyy/mm/dd'),'Casa',20000000);

INSERT INTO Avisos VALUES ('98765', '14785', TO_DATE('2024/08/11', 'yyyy/mm/dd'), 'Recib� notificaci�n...', 'Pendiente', 'AdministradorNegocio');
INSERT INTO Avisos VALUES ('45678', '96325', TO_DATE('2024/07/14', 'yyyy/mm/dd'), 'Busco asesor�a legal...', 'Enviada', 'Due�odelaInfo');
INSERT INTO Avisos VALUES ('12365', '25897', TO_DATE('2024/12/02', 'yyyy/mm/dd'), 'Informarle situaci�n...', 'Fallida', 'Due�odelaInfo');


INSERT INTO OrigenFondos VALUES ('98765', 300000000, 'Cr?ditoH', 'Aprobado');
INSERT INTO OrigenFondos VALUES ('45678', 800000, 'Cr?ditoP',null);
INSERT INTO OrigenFondos VALUES ('12365', 15000000, 'Ahorro', 'Pendiente');

INSERT INTO InteresEn VALUES ('98765432100', '98765', 'Alto');
INSERT INTO InteresEn VALUES ('12345678900', '45678', 'Medio');
INSERT INTO InteresEn VALUES ('09876543211', '12365', 'Bajo');

INSERT INTO Ofertas VALUES ('98765432100', '67890', TO_DATE('2024/09/25', 'yyyy/mm/dd'), 'Calle 123 #45-67', 'Bodega', 450000000, NULL, 'Pendiente', '10001');
INSERT INTO Ofertas VALUES ('12345678900', '54321', TO_DATE('2024/03/15', 'yyyy/mm/dd'), 'Avenida 789 #12-34', 'Apartamento', 1200000, 'Contrato.pdf', 'Aceptada', '10001');
INSERT INTO Ofertas VALUES ('09876543211', '98765', TO_DATE('2024/07/30', 'yyyy/mm/dd'), 'Calle 567 #89-90', 'Casa', 25000000, 'Fotos.zip', 'Rechazada', '10003');

INSERT INTO Fotografias VALUES ('Foto1', '/imagenes/foto1.jpg', 'Vista frontal de la propiedad');
INSERT INTO Fotografias VALUES ('Foto2', '/imagenes/foto2.jpg', 'Vista interior del apartamento');
INSERT INTO Fotografias VALUES ('Foto3', '/imagenes/foto3.jpg', 'Vista panor?mica del barrio');

INSERT INTO PermiteFotografias VALUES ('67890', 'Foto1');
INSERT INTO PermiteFotografias VALUES ('54321', 'Foto2');
INSERT INTO PermiteFotografias VALUES ('98765', 'Foto3');

INSERT INTO OpcionesCreditos VALUES (20, 15000000, '67890');
INSERT INTO OpcionesCreditos VALUES (15, 1000000, '54321');
INSERT INTO OpcionesCreditos VALUES (30, 500000, '98765');

INSERT INTO Ubicaciones VALUES ('98765432100', -74, 485, 'Bogot?', 'Norte', 'Chapinero');
INSERT INTO Ubicaciones VALUES ('12345678900', -98, 197, 'M?xico', 'Centro', 'Lomas');
INSERT INTO Ubicaciones VALUES ('09876543211', -545, -387, 'BuenoAire', 'Sur', 'Palermo');

INSERT INTO Notificaciones VALUES ('00101', TO_DATE('2024/10/10', 'yyyy/mm/dd'), 'Notificaci�n recibida', 'Le�da', 'usuario01');
INSERT INTO Notificaciones VALUES ('00102', TO_DATE('2024/10/11', 'yyyy/mm/dd'), 'Recordatorio de pago', 'Enviada', 'usuario02');
INSERT INTO Notificaciones VALUES ('00103', TO_DATE('2024/10/12', 'yyyy/mm/dd'), 'Actualizaci�n de datos', 'Pendiente', 'usuario03');

INSERT INTO Alertas VALUES ('14785', TO_DATE('2024/10/10', 'yyyy/mm/dd'), 'Revisar documentos', 'Pendiente', 'usuario01', 'Activa', TO_DATE('2024/10/10 10:00:00', 'yyyy/mm/dd hh24:mi:ss'), 'Documento vencido');
INSERT INTO Alertas VALUES ('96325', TO_DATE('2024/10/11', 'yyyy/mm/dd'), 'Pago pendiente', 'Enviada', 'usuario02', 'Urgente', TO_DATE('2024/10/11 09:00:00', 'yyyy/mm/dd hh24:mi:ss'), 'Pago mensualidad');
INSERT INTO Alertas VALUES ('25897', TO_DATE('2024/10/12', 'yyyy/mm/dd'), 'Actualizaci�n de contrato', 'Pendiente', 'usuario03', 'Normal', TO_DATE('2024/10/12 15:00:00', 'yyyy/mm/dd hh24:mi:ss'), 'Contrato por vencer');


/*PoblarNoOK*/
INSERT INTO Demandas VALUES ('999999', '12345', TO_DATE('2024/09/01', 'yyyy/mm/dd'), 'Casa', 500000000); /*El id del usuario no existe en usuarios*/
INSERT INTO OrigenFondos VALUES ('12345', 'cien mil', 'Cr?ditoH', 'Aprobado');/*Para la segunda casilla corresponde aun valor tipo entero, no de cadena*/
INSERT INTO Usuarios VALUES ('10004', TO_DATE('2024/10/01', 'yyyy/mm/dd'), NULL, '3125555555');/*Coloca un Null en columna definifa como no null*/


INSERT INTO Usuarios VALUES ('10005', TO_DATE('2024/09/30', 'yyyy/mm/dd'), 'usuario05gmail.com', '3125555555');/*Recibe correos sin @*/
INSERT INTO Demandas VALUES ('10001', '98766', TO_DATE('2024/09/29', 'yyyy/mm/dd'), 'Casa', -50000000);/*el valos maximo de la compra es negativo*/
INSERT INTO PersonaNaturales VALUES ('Cedula', '1234567', 'Carlos', 'Colombiana', '10004'); /*Ingrsan 2 personas distintas con el mismo numero de cedula*/
INSERT INTO PersonaNaturales VALUES ('Cedula', '1234567', 'Luis', 'Colombiana', '10005');
/**/

/*XPoblar*/
DELETE FROM Usuarios;
DELETE FROM PersonaNaturales;
DELETE FROM Empresas;
DELETE FROM Demandas;
DELETE FROM Avisos;
DELETE FROM OrigenFondos;
DELETE FROM InteresEn;
DELETE FROM Ofertas;
DELETE FROM Fotografias;
DELETE FROM PermiteFotografias;
DELETE FROM OpcionesCreditos;
DELETE FROM Ubicaciones;
DELETE FROM Notificaciones;
DELETE FROM Alertas;

/*PK*/
ALTER TABLE Usuarios
ADD CONSTRAINT PK_Usuarios PRIMARY KEY (id);

ALTER TABLE PersonaNaturales
ADD CONSTRAINT PK_PersonaNaturales PRIMARY KEY (nombres);

ALTER TABLE Empresas
ADD CONSTRAINT PK_Empresas PRIMARY KEY (razonSocial);

ALTER TABLE Demandas
ADD CONSTRAINT PK_Demandas PRIMARY KEY (numero);

ALTER TABLE Avisos
ADD CONSTRAINT PK_Avisos PRIMARY KEY (id);

ALTER TABLE OrigenFondos
ADD CONSTRAINT PK_OrigenFondos PRIMARY KEY (valor);

ALTER TABLE InteresEn
ADD CONSTRAINT PK_InteresEn PRIMARY KEY (numeroDemanda, codigoUbicacion);

ALTER TABLE Ofertas
ADD CONSTRAINT PK_Ofertas PRIMARY KEY (numero);

ALTER TABLE Fotografias
ADD CONSTRAINT PK_Fotografias PRIMARY KEY (nombre);

ALTER TABLE PermiteFotografias
ADD CONSTRAINT PK_PermiteFotografias PRIMARY KEY (numeroOferta, nombreFotografia);

ALTER TABLE OpcionesCreditos
ADD CONSTRAINT PK_OpcionesCreditos PRIMARY KEY (plazo);

ALTER TABLE Ubicaciones
ADD CONSTRAINT PK_Ubicaciones PRIMARY KEY (codigo);

ALTER TABLE Alertas
ADD CONSTRAINT PK_ALERTAS PRIMARY KEY (alertaEstado);

ALTER TABLE Notificaciones
ADD CONSTRAINT PK_NOTIFICACIONES PRIMARY KEY(mensaje);
/*FK*/

ALTER TABLE PersonaNaturales
ADD CONSTRAINT FK_PersonaNaturales_Usuarios FOREIGN KEY (idusuario)
REFERENCES Usuarios(id);

ALTER TABLE Empresas
ADD CONSTRAINT FK_Empresas_Usuarios FOREIGN KEY (idusuario)
REFERENCES Usuarios(id);

ALTER TABLE Demandas
ADD CONSTRAINT FK_Demandas_Usuarios FOREIGN KEY (idusuario)
REFERENCES Usuarios(id);

ALTER TABLE Avisos
ADD CONSTRAINT FK_Avisos_Demandas FOREIGN KEY (numeroDemanda)
REFERENCES Demandas(numero);

ALTER TABLE OrigenFondos
ADD CONSTRAINT FK_OrigenFondos_Demandas FOREIGN KEY (numeroDemanda)
REFERENCES Demandas(numero);

ALTER TABLE InteresEn
ADD CONSTRAINT FK_InteresEn_Ubicaciones FOREIGN KEY (codigoUbicacion)
REFERENCES Ubicaciones(codigo);

ALTER TABLE InteresEn
ADD CONSTRAINT FK_InteresEn_Demandas FOREIGN KEY (numeroDemanda)
REFERENCES Demandas(numero);

ALTER TABLE Ofertas
ADD CONSTRAINT FK_Ofertas_Ubicaciones FOREIGN KEY (codigoUbicacion)
REFERENCES Ubicaciones(codigo);

ALTER TABLE Ofertas
ADD CONSTRAINT FK_Ofertas_Usuarios FOREIGN KEY (idusuario)
REFERENCES Usuarios(id);

ALTER TABLE PermiteFotografias
ADD CONSTRAINT FK_PermiteFotografias_Ofertas FOREIGN KEY (numeroOferta)
REFERENCES Ofertas(numero);

ALTER TABLE PermiteFotografias
ADD CONSTRAINT FK_PermiteFotografias_Fotografias FOREIGN KEY (nombreFotografia)
REFERENCES Fotografias(nombre);

ALTER TABLE OpcionesCreditos
ADD CONSTRAINT FK_OpcionesCreditos_Ofertas FOREIGN KEY (numeroOferta)
REFERENCES Ofertas(numero);

ALTER TABLE Alertas
ADD CONSTRAINT FK_Alertas_Avisos FOREIGN KEY (idAlertas)
REFERENCES Avisos(id);

ALTER TABLE Notificaciones
ADD CONSTRAINT FK_Notificaciones_Avisos FOREIGN KEY (idNotificaciones) /*genera error*/
REFERENCES Avisos(id);

/*UK*/

ALTER TABLE PersonaNaturales
ADD CONSTRAINT Uk_PersonaNaturales UNIQUE (tipoDocumento, numeroDocumento);

ALTER TABLE Empresas
ADD CONSTRAINT Uk_Empresas_Nit UNIQUE (nit);

/*Atributos*/

ALTER TABLE Usuarios
ADD CONSTRAINT CK_Usuarios_Correo CHECK (correoElectronico LIKE '%@%');

ALTER TABLE Demandas
ADD CONSTRAINT CK_Demandas_MaxCompra CHECK (maxCompra > 0);

/*Para el primer y segundo caso, ya implementamos las restriciones pertienentes*/
/*Para el tercer caso, con la implementacion de la UK recupera integridad*/

INSERT INTO PersonaNaturales VALUES ('Cedula','9876543', null, 'Argentino','10003'); /*Se va a rechazar porque el valor en el nombre no puede ser null*/
INSERT INTO Usuarios VALUES ('1000189',TO_DATE('28-SEP-2024 20:55:00', 'DD-MON-YYYY HH24:MI:SS'),'usuario01@gmail.com','3124338358'); /*La insercion sera negada porque el id se desborda*/
INSERT INTO Usuarios VALUES ('10005', TO_DATE('2024/09/30', 'yyyy/mm/dd'), 'usuario05gmail.com', '3125555555');/*Recibe correos sin @*/ /*No recibira valores de correo sin el @*/

/*nuevas inserciones punto F*/

-- Usuarios
INSERT INTO Usuarios VALUES ('U1001', TO_DATE('2024-01-01', 'YYYY-MM-DD'), 'juandipt00@mail.com', '3011112222');
INSERT INTO Usuarios VALUES ('U1002', TO_DATE('2024-02-01', 'YYYY-MM-DD'), 'nuevo_usuario2@mail.com', '3012223333');
INSERT INTO Usuarios VALUES ('U1003', TO_DATE('2024-03-01', 'YYYY-MM-DD'), 'nuevo_usuario3@mail.com', '3013334444');
INSERT INTO Usuarios VALUES ('U1004', TO_DATE('2024-04-01', 'YYYY-MM-DD'), 'nuevo_usuario4@mail.com', '3014445555');
INSERT INTO Usuarios VALUES ('U1005', TO_DATE('2024-05-01', 'YYYY-MM-DD'), 'nuevo_usuario5@mail.com', '3015556666');
INSERT INTO Usuarios VALUES ('U1006', TO_DATE('2024-06-01', 'YYYY-MM-DD'), 'nuevo_usuario6@mail.com', '3016667777');
INSERT INTO Usuarios VALUES ('U1007', TO_DATE('2024-07-01', 'YYYY-MM-DD'), 'nuevo_usuario7@mail.com', '3017778888');
INSERT INTO Usuarios VALUES ('U1008', TO_DATE('2024-08-01', 'YYYY-MM-DD'), 'nuevo_usuario8@mail.com', '3018889999');
INSERT INTO Usuarios VALUES ('U1009', TO_DATE('2024-09-01', 'YYYY-MM-DD'), 'nuevo_usuario9@mail.com', '3019990000');
INSERT INTO Usuarios VALUES ('U1010', TO_DATE('2024-10-01', 'YYYY-MM-DD'), 'juandipt00@mail.com', '3020001111');

-- PersonaNaturales
INSERT INTO PersonaNaturales VALUES ('Cedula', '123123123', 'Pedro', 'Colombia', 'U1001');
INSERT INTO PersonaNaturales VALUES ('Cedula', '321321321', 'Ana', 'Colombia', 'U1002');
INSERT INTO PersonaNaturales VALUES ('Cedula', '456456456', 'Sofia', 'Colombia', 'U1003');
INSERT INTO PersonaNaturales VALUES ('Cedula', '654654654', 'Luis', 'Colombia', 'U1004');
INSERT INTO PersonaNaturales VALUES ('Cedula', '789789789', 'Marta', 'Colombia', 'U1005');
INSERT INTO PersonaNaturales VALUES ('Cedula', '147147147', 'Carlos', 'Colombia', 'U1006');
INSERT INTO PersonaNaturales VALUES ('Cedula', '258258258', 'Laura', 'Colombia', 'U1007');
INSERT INTO PersonaNaturales VALUES ('Cedula', '369369369', 'Jose', 'Colombia', 'U1008');
INSERT INTO PersonaNaturales VALUES ('Cedula', '987987987', 'Julia', 'Colombia', 'U1009');
INSERT INTO PersonaNaturales VALUES ('Cedula', '654123987', 'Fernando', 'Colombia', 'U1010');

-- Empresas
INSERT INTO Empresas VALUES ('9012345678', 'Empresa A S.A.S.', 'U1001');
INSERT INTO Empresas VALUES ('9023456789', 'Empresa B S.A.S.', 'U1002');
INSERT INTO Empresas VALUES ('9034567890', 'Empresa C S.A.S.', 'U1003');
INSERT INTO Empresas VALUES ('9045678901', 'Empresa D S.A.S.', 'U1004');
INSERT INTO Empresas VALUES ('9056789012', 'Empresa E S.A.S.', 'U1005');
INSERT INTO Empresas VALUES ('9067890123', 'Empresa F S.A.S.', 'U1006');
INSERT INTO Empresas VALUES ('9078901234', 'Empresa G S.A.S.', 'U1007');
INSERT INTO Empresas VALUES ('9089012345', 'Empresa H S.A.S.', 'U1008');
INSERT INTO Empresas VALUES ('9090123456', 'Empresa I S.A.S.', 'U1009');
INSERT INTO Empresas VALUES ('9001234560', 'Empresa J S.A.S.', 'U1010');

-- Demandas
INSERT INTO Demandas VALUES ('U1001', 'D1001', TO_DATE('2024-01-10', 'YYYY-MM-DD'), 'Casa', 60000000);
INSERT INTO Demandas VALUES ('U1002', 'D1002', TO_DATE('2024-02-10', 'YYYY-MM-DD'), 'Apartamento', 70000000);
INSERT INTO Demandas VALUES ('U1003', 'D1003', TO_DATE('2024-03-10', 'YYYY-MM-DD'), 'Casa', 80000000);
INSERT INTO Demandas VALUES ('U1004', 'D1004', TO_DATE('2024-04-10', 'YYYY-MM-DD'), 'Apartamento', 90000000);
INSERT INTO Demandas VALUES ('U1005', 'D1005', TO_DATE('2024-05-10', 'YYYY-MM-DD'), 'Casa', 100000000);
INSERT INTO Demandas VALUES ('U1006', 'D1006', TO_DATE('2024-06-10', 'YYYY-MM-DD'), 'Apartamento', 110000000);
INSERT INTO Demandas VALUES ('U1007', 'D1007', TO_DATE('2024-07-10', 'YYYY-MM-DD'), 'Casa', 120000000);
INSERT INTO Demandas VALUES ('U1008', 'D1008', TO_DATE('2024-08-10', 'YYYY-MM-DD'), 'Apartamento', 130000000);
INSERT INTO Demandas VALUES ('U1009', 'D1009', TO_DATE('2024-09-10', 'YYYY-MM-DD'), 'Casa', 140000000);
INSERT INTO Demandas VALUES ('U1010', 'D1010', TO_DATE('2024-10-10', 'YYYY-MM-DD'), 'Apartamento', 150000000);

-- Avisos
INSERT INTO Avisos VALUES ('D1001', 'A1001', 'Notificacion', TO_DATE('2024-01-11', 'YYYY-MM-DD'), 'Mensaje 1', 'Activo', 'Pedro');
INSERT INTO Avisos VALUES ('D1002', 'A1002', 'Notificacion', TO_DATE('2024-02-11', 'YYYY-MM-DD'), 'Mensaje 2', 'Activo', 'Ana');
INSERT INTO Avisos VALUES ('D1003', 'A1003', 'Alerta', TO_DATE('2024-03-11', 'YYYY-MM-DD'), 'Mensaje 3', 'Sofia');
INSERT INTO Avisos VALUES ('D1004', 'A1004', 'Notificacion', TO_DATE('2024-04-11', 'YYYY-MM-DD'), 'Mensaje 4', 'Luis');
INSERT INTO Avisos VALUES ('D1005', 'A1005', 'Alerta', TO_DATE('2024-05-11', 'YYYY-MM-DD'), 'Mensaje 5', 'Marta');
INSERT INTO Avisos VALUES ('D1006', 'A1006', 'Notificacion', TO_DATE('2024-06-11', 'YYYY-MM-DD'), 'Mensaje 6', 'Carlos');
INSERT INTO Avisos VALUES ('D1007', 'A1007', 'Notificacion', TO_DATE('2024-07-11', 'YYYY-MM-DD'), 'Mensaje 7', 'Laura');
INSERT INTO Avisos VALUES ('D1008', 'A1008', 'Notificacion', TO_DATE('2024-08-11', 'YYYY-MM-DD'), 'Mensaje 8', 'Jose');
INSERT INTO Avisos VALUES ('D1009', 'A1009', 'Alerta', TO_DATE('2024-09-11', 'YYYY-MM-DD'), 'Mensaje 9', 'Julia');
INSERT INTO Avisos VALUES ('D1010', 'A1010', 'Alerta', TO_DATE('2024-10-11', 'YYYY-MM-DD'), 'Mensaje 10', 'Fernando');

-- OrigenFondos
INSERT INTO OrigenFondos VALUES ('D1001', 40000000, 'CreditoBancario', 'Si');
INSERT INTO OrigenFondos VALUES ('D1002', 50000000, 'Ahorros', 'No');
INSERT INTO OrigenFondos VALUES ('D1003', 60000000, 'PrestFamiliar', 'Si');
INSERT INTO OrigenFondos VALUES ('D1004', 70000000, 'CHipotecario', 'Si');
INSERT INTO OrigenFondos VALUES ('D1005', 80000000, 'Ahorros', 'No');
INSERT INTO OrigenFondos VALUES ('D1006', 90000000, 'CreditoBancario', 'Si');
INSERT INTO OrigenFondos VALUES ('D1007', 100000000, 'PrestFamiliar', 'Si');
INSERT INTO OrigenFondos VALUES ('D1008', 110000000, 'Ahorros', 'No');
INSERT INTO OrigenFondos VALUES ('D1009', 120000000, 'CHipotecario', 'Si');
INSERT INTO OrigenFondos VALUES ('D1010', 130000000, 'CreditoBancario', 'No');

-- Ubicaciones
INSERT INTO Ubicaciones VALUES ('LOC00000011', 110, 210, 'Cali', 'Norte', 'El Pe��n');
INSERT INTO Ubicaciones VALUES ('LOC00000012', 111, 211, 'Cartagena', 'Sur', 'Bocagrande');
INSERT INTO Ubicaciones VALUES ('LOC00000013', 112, 212, 'Barranquilla', 'Centro', 'El Prado');
INSERT INTO Ubicaciones VALUES ('LOC00000014', 113, 213, 'Medellin', 'Norte', 'Poblado');
INSERT INTO Ubicaciones VALUES ('LOC00000015', 114, 214, 'Bogota', 'Oeste', 'Chapinero');
INSERT INTO Ubicaciones VALUES ('LOC00000016', 115, 215, 'Bucaramanga', 'Centro', 'Cabecera');
INSERT INTO Ubicaciones VALUES ('LOC00000017', 116, 216, 'Pereira', 'Norte', 'Lago La Pradera');
INSERT INTO Ubicaciones VALUES ('LOC00000018', 117, 217, 'Cali', 'Sur', 'La Flora');
INSERT INTO Ubicaciones VALUES ('LOC00000019', 118, 218, 'C�cuta', 'Centro', 'La Playa');
INSERT INTO Ubicaciones VALUES ('LOC00000020', 119, 219, 'Cali', 'Este', 'Aguascalientes');

-- InteresEn
INSERT INTO InteresEn VALUES ('LOC00000011', 'D1001', 'Alta');
INSERT INTO InteresEn VALUES ('LOC00000012', 'D1002', 'Media');
INSERT INTO InteresEn VALUES ('LOC00000013', 'D1003', 'Alta');
INSERT INTO InteresEn VALUES ('LOC00000014', 'D1004', 'Baja');
INSERT INTO InteresEn VALUES ('LOC00000015', 'D1005', 'Media');
INSERT INTO InteresEn VALUES ('LOC00000016', 'D1006', 'Alta');
INSERT INTO InteresEn VALUES ('LOC00000017', 'D1007', 'Baja');
INSERT INTO InteresEn VALUES ('LOC00000018', 'D1008', 'Media');
INSERT INTO InteresEn VALUES ('LOC00000019', 'D1009', 'Alta');
INSERT INTO InteresEn VALUES ('LOC00000020', 'D1010', 'Baja');

-- Ofertas
INSERT INTO Ofertas VALUES ('LOC00000011', 'O1001', TO_DATE('2024-01-20', 'YYYY-MM-DD'), 'Calle Nueva', 'Casa', 60000000, NULL, 'Activo', 'U1001');
INSERT INTO Ofertas VALUES ('LOC00000012', 'O1002', TO_DATE('2024-02-20', 'YYYY-MM-DD'), 'Carrera 20', 'Apartamento', 65000000, NULL, 'Activo', 'U1002');
INSERT INTO Ofertas VALUES ('LOC00000013', 'O1003', TO_DATE('2024-03-20', 'YYYY-MM-DD'), 'Calle Vieja', 'Casa', 70000000, 'PDF1', 'Activo', 'U1003');
INSERT INTO Ofertas VALUES ('LOC00000014', 'O1004', TO_DATE('2024-04-20', 'YYYY-MM-DD'), 'Carrera 30', 'Apartamento', 75000000, NULL, 'Activo', 'U1004');
INSERT INTO Ofertas VALUES ('LOC00000015', 'O1005', TO_DATE('2024-05-20', 'YYYY-MM-DD'), 'Calle Nueva', 'Casa', 80000000, NULL, 'Activo', 'U1005');
INSERT INTO Ofertas VALUES ('LOC00000016', 'O1006', TO_DATE('2024-06-20', 'YYYY-MM-DD'), 'Carrera 40', 'Apartamento', 85000000, NULL, 'Activo', 'U1006');
INSERT INTO Ofertas VALUES ('LOC00000017', 'O1007', TO_DATE('2024-07-20', 'YYYY-MM-DD'), 'Calle Antigua', 'Casa', 90000000, 'PDF2', 'Activo', 'U1007');
INSERT INTO Ofertas VALUES ('LOC00000018', 'O1008', TO_DATE('2024-08-20', 'YYYY-MM-DD'), 'Carrera 50', 'Apartamento', 95000000, 'PDF3', 'Activo', 'U1008');
INSERT INTO Ofertas VALUES ('LOC00000019', 'O1009', TO_DATE('2024-09-20', 'YYYY-MM-DD'), 'Calle Principal', 'Casa', 100000000, NULL, 'Activo', 'U1009');
INSERT INTO Ofertas VALUES ('LOC00000020', 'O1010', TO_DATE('2024-10-20', 'YYYY-MM-DD'), 'Carrera Secundaria', 'Apartamento', 105000000, 'PDF4', 'Activo', 'U1010');

-- Fotografias
INSERT INTO Fotografias VALUES ('Foto11', '/ruta/nueva_foto1.jpg', 'Foto de la nueva casa');
INSERT INTO Fotografias VALUES ('Foto12', '/ruta/nueva_foto2.jpg', 'Foto del nuevo apartamento');
INSERT INTO Fotografias VALUES ('Foto13', '/ruta/nueva_foto3.jpg', 'Foto del nuevo exterior');
INSERT INTO Fotografias VALUES ('Foto14', '/ruta/nueva_foto4.jpg', 'Foto de la nueva sala');
INSERT INTO Fotografias VALUES ('Foto15', '/ruta/nueva_foto5.jpg', 'Foto del nuevo comedor');
INSERT INTO Fotografias VALUES ('Foto16', '/ruta/nueva_foto6.jpg', 'Foto de la nueva cocina');
INSERT INTO Fotografias VALUES ('Foto17', '/ruta/nueva_foto7.jpg', 'Foto del nuevo dormitorio');
INSERT INTO Fotografias VALUES ('Foto18', '/ruta/nueva_foto8.jpg', 'Foto del nuevo ba�o');
INSERT INTO Fotografias VALUES ('Foto19', '/ruta/nueva_foto9.jpg', 'Foto del nuevo balc�n');
INSERT INTO Fotografias VALUES ('Foto20', '/ruta/nueva_foto10.jpg', 'Foto del nuevo garaje');

-- PermiteFotografias
INSERT INTO PermiteFotografias VALUES ('O1001', 'Foto11');
INSERT INTO PermiteFotografias VALUES ('O1002', 'Foto12');
INSERT INTO PermiteFotografias VALUES ('O1003', 'Foto13');
INSERT INTO PermiteFotografias VALUES ('O1004', 'Foto14');
INSERT INTO PermiteFotografias VALUES ('O1005', 'Foto15');
INSERT INTO PermiteFotografias VALUES ('O1006', 'Foto16');
INSERT INTO PermiteFotografias VALUES ('O1007', 'Foto17');
INSERT INTO PermiteFotografias VALUES ('O1008', 'Foto18');
INSERT INTO PermiteFotografias VALUES ('O1009', 'Foto19');
INSERT INTO PermiteFotografias VALUES ('O1010', 'Foto20');

-- OpcionesCreditos
INSERT INTO OpcionesCreditos VALUES (12, 1200000, 'O1001');
INSERT INTO OpcionesCreditos VALUES (24, 1600000, 'O1002');
INSERT INTO OpcionesCreditos VALUES (36, 2000000, 'O1003');
INSERT INTO OpcionesCreditos VALUES (48, 2500000, 'O1004');
INSERT INTO OpcionesCreditos VALUES (60, 3000000, 'O1005');
INSERT INTO OpcionesCreditos VALUES (72, 3500000, 'O1006');
INSERT INTO OpcionesCreditos VALUES (84, 4000000, 'O1007');
INSERT INTO OpcionesCreditos VALUES (96, 4500000, 'O1008');
INSERT INTO OpcionesCreditos VALUES (108, 5000000, 'O1009');
INSERT INTO OpcionesCreditos VALUES (120, 5500000, 'O1010');



/*Xtablas*/
DROP TABLE Usuarios CASCADE CONSTRAINTS;
DROP TABLE PersonaNaturales CASCADE CONSTRAINTS;
DROP TABLE Empresas CASCADE CONSTRAINTS;
DROP TABLE Demandas CASCADE CONSTRAINTS;
DROP TABLE Avisos CASCADE CONSTRAINTS;
DROP TABLE OrigenFondos CASCADE CONSTRAINTS;
DROP TABLE InteresEn CASCADE CONSTRAINTS;
DROP TABLE Ofertas CASCADE CONSTRAINTS;
DROP TABLE Fotografias CASCADE CONSTRAINTS;
DROP TABLE PermiteFotografias CASCADE CONSTRAINTS;
DROP TABLE OpcionesCreditos CASCADE CONSTRAINTS;
DROP TABLE Ubicaciones CASCADE CONSTRAINTS;
DROP TABLE Alertas CASCADE CONSTRAINTS;
DROP TABLE Notificaciones CASCADE CONSTRAINTS;
