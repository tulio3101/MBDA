DROP VIEW Entidades_Diagnostico;
DROP INDEX IndicePacientes;
DROP INDEX IndiceHistorias;