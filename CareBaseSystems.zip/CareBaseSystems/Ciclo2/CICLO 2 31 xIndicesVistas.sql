DROP INDEX Indice_Pruebas_Laboratorio;
DROP INDEX Indice_Jornadas_Vacunacion;
DROP VIEW Vista_Pacientes_Pruebas_Diagnosticos;